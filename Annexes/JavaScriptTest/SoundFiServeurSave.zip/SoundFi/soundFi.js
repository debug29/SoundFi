  var analyser = null;
  var audioContext = null;
  var mediaStreamSource = null;
  var filter = null;
  var frequencyData = null;
  var timeIntervall = null;
  var tabMessage = [];
  var compteur = 0;
  var frequency = 0;

  var yoloTimer = null;

    // success callback when requesting audio input stream
  function gotStream(stream) {
      window.AudioContext = window.AudioContext || window.webkitAudioContext;
      audioContext = new AudioContext();
      console.log(audioContext.sampleRate);
      // Create an AudioNode from the stream.
      mediaStreamSource = audioContext.createMediaStreamSource( stream );

      //Create an high pass filter
      filter = audioContext.createBiquadFilter();
      filter.frequency.value = 17500.0;
      filter.type = "highpass";
      filter.Q = 10.0;

      mediaStreamSource.connect(filter)
      
      //Create an analyser
      analyser = audioContext.createAnalyser();
      analyser.fftSize=2048;
      analyser.minDecibels = -90;
      console.log(analyser.fftSize);
      console.log(analyser.frequencyBinCount);
      frequencyData = new Float32Array(analyser.frequencyBinCount);
      filter.connect(analyser);

      //


      // Connect it to the destination to hear yourself (or any other node for processing!)
      //analyser.connect( audioContext.destination );

      raf(update);    
  }

  function errorStream(){
    alert('Something went wrong :/');
  }

  function update(){
    analyser.getFloatFrequencyData(frequencyData);
    var maxBin=frequencyData[0];
    var index=0;

    // Recherche du pic
    for(var i=0;i<frequencyData.length;i++){
      if(frequencyData[i]>maxBin && frequencyData[i]>-80){
        maxBin=frequencyData[i];
        index=i;
      }
      i++;

    }

    if (index!=0){
      var currentFrequency = ((audioContext.sampleRate / 2.) / frequencyData.length) * index;
      if (currentFrequency>17500){
        if (frequency >= currentFrequency-5 || frequency <= currentFrequency+5){
          compteur++;
        }
        else{
          compteur = 0;
        }

        if (compteur>10){
          console.log("valide :" + frequency);
          compteur = 0;
          changeImage(frequency);
        }

        frequency=currentFrequency;
        /*
        console.log(currentFrequency);
        tabMessage[tabMessage.length]=String.fromCharCode(32 + Math.round(((currentFrequency-17959)/43.066)));
        */
        console.log(String.fromCharCode(32 + Math.round(((currentFrequency-17959)/43.066))));
        
      }
    }

    raf(update);
  }

  function raf(callback) {
    //timeIntervall = setInterval(callback,20);
    //setTimeout(callback, 2000);
    
    var isCrx = chrome.app.runtime || chrome.extension;
    if (isCrx) {
      setTimeout(callback, 46);
    } else {
      requestAnimationFrame(callback);
    }
    
  }

  function kill(){
    console.log("Arret de la boucle");
    clearInterval(timeIntervall);
  }

  function info(){
    if (frequencyData!=null){
        analyser.getFloatFrequencyData(frequencyData);
      
        for(var i = 0;i<frequencyData.length;i++){
          console.log(frequencyData[i]);
        }
    }
  }

  function changeImage(freq){
    var indexFreq = Math.round((freq - 17959)/43);
    var img = document.getElementById("imageTest");

    switch(indexFreq){
      case 48:
        img.src="fr.png";
        console.log("48");
      break;
      case 49:
        img.src="al.png";
        console.log("49");
      break;
      case 50:
        img.src="it.png";
        console.log("50");
      break;
      case 51:
        img.src="sp.png";
        console.log("51");
      break;
      case 52:
        img.src="uk.png";
        console.log("52");
      break;
      case 53:
        img.src="yolo.png";
        console.log("53");
        document.getElementById("mp3").play();
      break;

    }

  }

  navigator.getUserMedia = navigator.getUserMedia || navigator.webkitGetUserMedia;
  navigator.getUserMedia( {audio:true}, gotStream,errorStream);








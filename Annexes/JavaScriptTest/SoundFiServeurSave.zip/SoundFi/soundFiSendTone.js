  var analyser = null;
  var audioContext = null;
  var oscillator = null;
  var periodicWave = null;
  var filter = null;
  var frequencyData = null;
  var timeIntervall = null;
  var date = null;
  var tabMessage = [];
  var compteur = 0;
  var frequency = 0;
  var compteur = 0;
  var nbrRepetition = 0;

    // success callback when requesting audio input stream
  function gotStream(stream) {
      window.AudioContext = window.AudioContext || window.webkitAudioContext;
      audioContext = new AudioContext();
      console.log(audioContext.sampleRate);
      
      /*
      //Creation d'un ocillateur
      oscillator = audioContext.createOscillator();
      oscillator.type = "sine";
      oscillator.frequency.value = 0;

      //Sortie
      oscillator.connect(audioContext.destination);

      oscillator.start();
      */
  }

  function startOscillo(){
      //periodicWave = audioContext.createPeriodicWave(0.5,0.5);
      //oscillator.setPeriodicWave(periodicWave);
      //Démarrage de l'oscillateur
      oscillator.start();
  }

  function stopOscillo(){
    oscillator.stop();
  }

  function errorStream(){
    alert('Something went wrong :/');
  }

  function sendMessage(){
    //A appeler périodiquement celon une sample rate;
    //timeIntervall = setInterval(frequencyLoad,46);
    var message = "Note:" + document.getElementById('inputText').value;
    if (message!=null)
      frequencyLoad(message);
  }

function frequencyLoad(message){
 
  var frequencies = [];
  frequencies[0]=17800;
  frequencies[1]=17800;
  frequencies[2]=17800;
  for(var i=0;i<message.length;i++){
    frequencies[frequencies.length]=18000 + (message.charCodeAt(i)-32)*18;
    console.log(frequencies[i+1]);
  }
  frequencies[frequencies.length]=19728;

  for(var i=0;i<frequencies.length;i++){
    var time = audioContext.currentTime + 0.038 * i;
    //console.log("Current time :" + audioContext.currentTime);
    sendTone(frequencies[i],time,0.038);
  }
}

function sendTone(freq, startTime, duration){
  //console.log("Freq :" +freq);
  //console.log("Debut :" +startTime);
  //console.log("Duree :" +duration);
  
  var gainNode = audioContext.createGainNode();
  // Gain => Merger
  gainNode.gain.value = 1;

  
  gainNode.gain.setValueAtTime(0, startTime);
  gainNode.gain.linearRampToValueAtTime(1, startTime + 0.001);
  gainNode.gain.setValueAtTime(1, startTime + duration - 0.001);
  gainNode.gain.linearRampToValueAtTime(0, startTime + duration);
  
  gainNode.connect(audioContext.destination);

  var osc = audioContext.createOscillator();
  osc.frequency.value = freq;
  osc.connect(gainNode);

  osc.start(startTime);
}
  navigator.getUserMedia = navigator.getUserMedia || navigator.webkitGetUserMedia;
  navigator.getUserMedia( {audio:true}, gotStream,errorStream);